let currentPlayer = 'X';
let gameBoard = Array(9).fill('');

const winningCombinations = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
  [0, 4, 8], [2, 4, 6]             // diagonals
];

function makeMove(cell) {
  const index = Array.from(cell.parentNode.children).indexOf(cell);

  if (gameBoard[index] === '' && !isGameOver()) {
    gameBoard[index] = currentPlayer;
    cell.textContent = currentPlayer;

    if (isGameOver()) {
      document.getElementById('status').textContent = `PLAYER ${currentPlayer} WINS! 🎉`;
    } else if (!gameBoard.includes('')) {
      document.getElementById('status').textContent = `IT'S A DRAW 😐`;
    } else {
      currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
      document.getElementById('status').textContent = `PLAYER ${currentPlayer === 'X' ? '1' : '2'}'S TURN (${currentPlayer})`;
    }
  }
}

function isGameOver() {
  return winningCombinations.some(combo => {
    const [a, b, c] = combo;
    return (
      gameBoard[a] &&
      gameBoard[a] === gameBoard[b] &&
      gameBoard[a] === gameBoard[c]
    );
  });
}

function resetGame() {
  gameBoard = Array(9).fill('');
  currentPlayer = 'X';
  document.getElementById('status').textContent = `PLAYER 1'S TURN (X)`;

  const cells = document.querySelectorAll('.cell');
  cells.forEach(cell => {
    cell.textContent = '';
  });
}
